<?php
// Koneksi ke database (gantilah dengan informasi koneksi sesuai kebutuhan)
$host = "localhost";
$username = "root";
$password = "";
$database = "pop";

$koneksi = mysqli_connect($host, $username, $password, $database);

// Periksa koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="pop-product.css">
    <title>DETAIL PESANAN</title>
</head>
<body>

    <?php
    // Ambil data OrderItem dari database
    $result = mysqli_query($db, "SELECT * FROM Public_Orders");
    $products = mysqli_fetch_all($result, MYSQLI_ASSOC);

    // Periksa apakah query berhasil dijalankan
    if (!$resultPublic_Orders) {
        die("Kesalahan query OrderItem: " . mysqli_error($koneksi));
    }

    // Simpan data OrderItem ke dalam array
    // $products = [];
    // while ($rowproducts = mysqli_fetch_assoc($resultproducts)) {
    //     $products[] = $rowproducts; 
    // }
    ?>

    <h1>DETAIL PESANAN</h1>

    <!-- Tabel untuk menampilkan informasi OrderItem -->
    <table border="1">
        <tr>
            <th>Nama Produk</th>
            <th>Harga per Item</th>
            <th>Jumlah</th>
            <th>Total Harga</th>
        </tr>

        <?php
        // Tampilkan informasi OrderItem
        foreach ($Public_Orders as $Public_Order)  {
            $totalPrice = $item['Product_Price'] * $item['Quantity'];
            echo "<tr>";
            echo "<td>" . $item['OrdersID'] . "</td>";
            echo "<td>" . $item['Full_Name'] . "</td>";
            echo "<td>" . $item['Product_Name'] . "</td>";
            echo "<td>" . $item['Product_Price'] . "</td>";
            echo "<td>" . $item['Quantity'] . "</td>";
            echo "<td>" . $totalPrice . "</td>";
            echo "</tr>";
        }
        ?>

    </table>

    <div class="but">
        <div class="b0">
            <button>
                <a href="index.php">PENGGUNA</a>
            </button>
        </div>
        <div class="b1">
            <button>
                <a href="pesanan.php">PESANAN</a>
            </button>
        </div>
        <div class="b2">
            <button>
                <a href="detailpesanan.php">DETAIL PESANAN</a>
            </button>
        </div>
        <div class="b3">
            <button>
                <a href="product.php">PRODUK</a>
            </button>
        </div>
        <div class="b4">
            <button>
                <a href="pricelist.php">PRICE LIST</a>
            </button>
        </div>
        <div class="b5">
            <button>
                <a href="Public_Orders.php">PUBLIC ORDERS</a>
            </button>
        </div>
    </div>

</body>
</html>
